'use client';

import { useState } from 'react';
import { motion } from 'motion/react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { Star, Clock, Filter, ChevronDown, Search } from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';

const filters = [
  { name: 'Filter', icon: Filter },
  { name: 'Sort By', icon: ChevronDown },
  { name: 'Fast Delivery', isNew: true },
  { name: 'Pure Spices', icon: ChevronDown },
  { name: 'Ratings 4.5+', icon: ChevronDown },
  { name: 'Price Range', icon: ChevronDown },
  { name: 'Offers', icon: ChevronDown },
];

const products = [
  {
    id: 1,
    name: "Premium Turmeric Powder",
    rating: 4.8,
    time: "20-25 mins",
    categories: "Pure Spices, Organic, Kitchen Essentials",
    location: "Erode Sourcing",
    offer: "50% OFF",
    image: "https://picsum.photos/seed/turmeric_p/600/400",
    isAd: true
  },
  {
    id: 2,
    name: "Authentic Garam Masala",
    rating: 4.9,
    time: "15-20 mins",
    categories: "Blends, Signature, Aromatic",
    location: "Heritage Recipe",
    offer: "₹100 OFF ABOVE ₹249",
    image: "https://picsum.photos/seed/masala_p/600/400",
    isAd: false
  },
  {
    id: 3,
    name: "Kashmiri Red Chilli",
    rating: 4.7,
    time: "30-40 mins",
    categories: "Pure Spices, Vibrant, Mild Heat",
    location: "Kashmir Valley",
    offer: "ITEMS AT ₹99",
    image: "https://picsum.photos/seed/chilli_p/600/400",
    isAd: true
  },
  {
    id: 4,
    name: "Special Chai Masala",
    rating: 5.0,
    time: "10-15 mins",
    categories: "Blends, Tea, Refreshing",
    location: "Family Secret",
    offer: "FREE DELIVERY",
    image: "https://picsum.photos/seed/chai_p/600/400",
    isAd: false
  },
  {
    id: 5,
    name: "Coriander Seeds",
    rating: 4.6,
    time: "40-45 mins",
    categories: "Whole Spices, Fresh, Earthy",
    location: "Rajasthan Farms",
    offer: "60% OFF UPTO ₹120",
    image: "https://picsum.photos/seed/coriander_p/600/400",
    isAd: true
  },
  {
    id: 6,
    name: "Black Pepper Whole",
    rating: 4.9,
    time: "25-30 mins",
    categories: "Whole Spices, Sharp, Premium",
    location: "Malabar Coast",
    offer: "50% OFF UPTO ₹100",
    image: "https://picsum.photos/seed/pepper_p/600/400",
    isAd: false
  },
  {
    id: 7,
    name: "Cumin Seeds (Jeera)",
    rating: 4.5,
    time: "20-25 mins",
    categories: "Whole Spices, Digestive, Daily",
    location: "Gujarat Sourcing",
    offer: "ITEMS AT ₹39",
    image: "https://picsum.photos/seed/cumin_p/600/400",
    isAd: true
  },
  {
    id: 8,
    name: "Biryani Masala",
    rating: 4.3,
    time: "20-25 mins",
    categories: "Blends, Festive, Royal",
    location: "Lucknowi Style",
    offer: "ITEMS AT ₹28",
    image: "https://picsum.photos/seed/biryani_p/600/400",
    isAd: false
  }
];

export default function ProductsPage() {
  return (
    <main className="min-h-screen bg-white">
      <Navbar />
      
      <div className="pt-32 pb-24 max-w-7xl mx-auto px-6">
        {/* Header Section */}
        <header className="mb-10">
          <h1 className="text-5xl font-serif font-bold text-stone-900 mb-4">Our Spices</h1>
          <p className="text-stone-500 text-lg max-w-2xl">
            Explore our wide range of premium spices and authentic blends to elevate your culinary creations.
          </p>
        </header>

        {/* Filters Section */}
        <div className="flex flex-wrap items-center gap-3 mb-12 overflow-x-auto pb-4 no-scrollbar">
          {filters.map((filter, i) => (
            <button
              key={i}
              className="flex items-center gap-2 px-4 py-2 border border-stone-200 rounded-full text-sm font-medium text-stone-700 hover:bg-stone-50 transition-colors whitespace-nowrap"
            >
              {filter.isNew && (
                <span className="bg-orange-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded leading-none">NEW</span>
              )}
              {filter.name}
              {filter.icon && <filter.icon size={16} className="text-stone-400" />}
            </button>
          ))}
        </div>

        {/* Results Info */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-stone-900">
            {products.length * 15} Varieties to explore
          </h2>
        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-8 gap-y-12">
          {products.map((product, index) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: (index % 4) * 0.1 }}
              className="group cursor-pointer"
            >
              {/* Image Container */}
              <div className="relative aspect-[4/3] rounded-2xl overflow-hidden mb-4 shadow-sm group-hover:shadow-md transition-shadow">
                <Image
                  src={product.image}
                  alt={product.name}
                  fill
                  className="object-cover transition-transform duration-500 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
                {/* Gradient Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-90" />
                
                {/* Offer Text */}
                <div className="absolute bottom-4 left-4">
                  <span className="text-white font-black text-xl tracking-tight uppercase">
                    {product.offer}
                  </span>
                </div>
              </div>

              {/* Product Info */}
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  {product.isAd && (
                    <span className="text-[10px] font-bold text-stone-400 border border-stone-200 px-1 rounded">Ad</span>
                  )}
                  <h3 className="text-lg font-bold text-stone-900 truncate group-hover:text-red-700 transition-colors">
                    {product.name}
                  </h3>
                </div>
                
                <div className="flex items-center gap-2 text-sm font-bold text-stone-700">
                  <div className="flex items-center gap-1 bg-emerald-600 text-white px-1.5 py-0.5 rounded text-xs">
                    <Star size={12} fill="currentColor" />
                    <span>{product.rating}</span>
                  </div>
                  <span className="text-stone-300">•</span>
                  <div className="flex items-center gap-1">
                    <Clock size={14} className="text-stone-400" />
                    <span>{product.time}</span>
                  </div>
                </div>

                <p className="text-sm text-stone-500 truncate">
                  {product.categories}
                </p>
                <p className="text-sm text-stone-400">
                  {product.location}
                </p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Load More Mock */}
        <div className="mt-20 flex justify-center">
          <button className="px-8 py-3 bg-stone-900 text-white font-bold rounded-xl hover:bg-red-700 transition-all shadow-lg">
            Show More Varieties
          </button>
        </div>
      </div>

      <Footer />
    </main>
  );
}
