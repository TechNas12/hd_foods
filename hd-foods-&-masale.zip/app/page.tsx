'use client';

import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import ProductGrid from '@/components/ProductGrid';
import StorySection from '@/components/StorySection';
import Footer from '@/components/Footer';
import { motion } from 'motion/react';
import Image from 'next/image';

export default function Home() {
  return (
    <main className="relative min-h-screen">
      <Navbar />
      
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <Hero />
        
        {/* Featured Categories - Glassmorphism Overlay */}
        <section className="relative z-30 -mt-24 max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            { title: "Pure Spices", count: "40+ Items", color: "bg-red-600" },
            { title: "Masala Blends", count: "25+ Items", color: "bg-yellow-600" },
            { title: "Whole Spices", count: "15+ Items", color: "bg-emerald-600" }
          ].map((cat, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 + 0.5 }}
              className="group relative p-8 bg-white/80 backdrop-blur-2xl rounded-3xl shadow-2xl border border-white/20 overflow-hidden cursor-pointer"
            >
              <div className={`absolute top-0 left-0 w-1 h-full ${cat.color} transition-all duration-500 group-hover:w-full opacity-10 group-hover:opacity-5`} />
              <h3 className="text-2xl font-serif font-bold text-stone-900 mb-2">{cat.title}</h3>
              <p className="text-stone-500 font-medium uppercase tracking-widest text-xs">{cat.count}</p>
              <div className="mt-6 flex items-center text-red-700 font-bold text-sm group-hover:gap-2 transition-all">
                Explore Collection <span className="opacity-0 group-hover:opacity-100 transition-opacity">→</span>
              </div>
            </motion.div>
          ))}
        </section>

        <ProductGrid />
        
        {/* Immersive Gallery Section */}
        <section className="py-24 bg-stone-900 text-white overflow-hidden">
          <div className="max-w-7xl mx-auto px-6">
            <div className="text-center mb-20">
              <span className="text-red-500 font-bold tracking-[0.3em] uppercase text-sm mb-4 block">Immersive Experience</span>
              <h2 className="text-5xl md:text-7xl font-serif mb-8">The Art of Spices</h2>
              <p className="text-white/60 max-w-2xl mx-auto text-lg">
                Spices are not just ingredients; they are stories of soil, sun, and centuries of tradition.
              </p>
            </div>
            
            <div className="grid grid-cols-12 gap-4 h-[800px]">
              <div className="col-span-12 md:col-span-8 h-full">
                <div className="relative h-full w-full rounded-3xl overflow-hidden group">
                  <Image 
                    src="https://picsum.photos/seed/art1/1200/800" 
                    alt="Spice Art" 
                    fill
                    className="object-cover transition-transform duration-1000 group-hover:scale-110"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-black/30 group-hover:bg-black/10 transition-colors" />
                  <div className="absolute bottom-10 left-10">
                    <h4 className="text-3xl font-serif font-bold mb-2">The Golden Harvest</h4>
                    <p className="text-white/70">Sourcing the finest turmeric from Erode.</p>
                  </div>
                </div>
              </div>
              <div className="col-span-12 md:col-span-4 flex flex-col gap-4 h-full">
                <div className="relative h-1/2 w-full rounded-3xl overflow-hidden group">
                  <Image 
                    src="https://picsum.photos/seed/art2/600/600" 
                    alt="Spice Art" 
                    fill
                    className="object-cover transition-transform duration-1000 group-hover:scale-110"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-black/30" />
                </div>
                <div className="relative h-1/2 w-full rounded-3xl overflow-hidden group">
                  <Image 
                    src="https://picsum.photos/seed/art3/600/600" 
                    alt="Spice Art" 
                    fill
                    className="object-cover transition-transform duration-1000 group-hover:scale-110"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-black/30" />
                </div>
              </div>
            </div>
          </div>
        </section>

        <StorySection />
        
        {/* CTA Section */}
        <section className="py-24 relative overflow-hidden">
          <div className="absolute inset-0 z-0">
            <Image 
              src="https://picsum.photos/seed/cta/1920/1080" 
              alt="CTA Background" 
              fill
              className="object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-red-900/80 backdrop-blur-sm" />
          </div>
          <div className="relative z-10 max-w-4xl mx-auto px-6 text-center text-white">
            <h2 className="text-5xl md:text-6xl font-serif font-bold mb-8 leading-tight">
              Ready to Transform Your Cooking?
            </h2>
            <p className="text-xl text-white/80 mb-12 max-w-2xl mx-auto">
              Join thousands of home chefs who trust HD Foods & Masale for their daily culinary adventures.
            </p>
            <button className="px-12 py-5 bg-white text-red-900 font-black rounded-full text-lg hover:bg-stone-100 transition-all transform hover:scale-105 shadow-2xl">
              Order Your Sample Kit
            </button>
          </div>
        </section>

        <Footer />
      </motion.div>
    </main>
  );
}
