'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShoppingBag, Menu, X, Search, User } from 'lucide-react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const pathname = usePathname();
  const isHome = pathname === '/';

  useEffect(() => {
    if (!isHome) return;

    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    
    window.addEventListener('scroll', handleScroll);
    handleScroll();

    return () => window.removeEventListener('scroll', handleScroll);
  }, [isHome]);

  const showScrolledStyle = isScrolled || !isHome;

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        showScrolledStyle
          ? 'py-4 bg-white/70 backdrop-blur-xl border-b border-stone-200 shadow-sm'
          : 'py-6 bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 group">
          <div className="w-10 h-10 bg-red-700 rounded-full flex items-center justify-center text-white font-bold text-xl border-2 border-yellow-500 overflow-hidden">
             <span className="font-serif italic">HD</span>
          </div>
          <span className={`font-serif text-xl font-bold tracking-tight transition-colors ${showScrolledStyle ? 'text-stone-900' : 'text-white'}`}>
            HD FOODS <span className="text-red-600">&</span> MASALE
          </span>
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center gap-8">
          {[
            { name: 'Home', href: '/' },
            { name: 'Spices', href: '/products' },
            { name: 'Blends', href: '/products?category=blends' },
            { name: 'Our Story', href: '/#our-story' },
            { name: 'Contact', href: '/#contact' }
          ].map((item) => (
            <Link
              key={item.name}
              href={item.href}
              className={`text-sm font-medium uppercase tracking-widest transition-colors hover:text-red-600 ${
                showScrolledStyle ? 'text-stone-600' : 'text-white/90'
              }`}
            >
              {item.name}
            </Link>
          ))}
        </div>

        {/* Icons */}
        <div className={`flex items-center gap-5 ${showScrolledStyle ? 'text-stone-900' : 'text-white'}`}>
          <button className={`p-2 rounded-full transition-colors ${showScrolledStyle ? 'hover:bg-stone-100' : 'hover:bg-white/10'}`}>
            <Search size={20} />
          </button>
          <button className={`p-2 rounded-full transition-colors ${showScrolledStyle ? 'hover:bg-stone-100' : 'hover:bg-white/10'}`}>
            <User size={20} />
          </button>
          <button className={`p-2 rounded-full transition-colors relative ${showScrolledStyle ? 'hover:bg-stone-100' : 'hover:bg-white/10'}`}>
            <ShoppingBag size={20} />
            <span className="absolute top-1 right-1 w-2 h-2 bg-red-600 rounded-full"></span>
          </button>
          <button
            className={`md:hidden p-2 rounded-full transition-colors ${showScrolledStyle ? 'hover:bg-stone-100' : 'hover:bg-white/10'}`}
            onClick={() => setIsMobileMenuOpen(true)}
          >
            <Menu size={24} />
          </button>
        </div>
      </div>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed inset-0 z-[60] bg-white flex flex-col p-8"
          >
            <div className="flex justify-end">
              <button
                onClick={() => setIsMobileMenuOpen(false)}
                className="p-2 text-stone-900 hover:bg-stone-100 rounded-full"
              >
                <X size={32} />
              </button>
            </div>
            <div className="flex flex-col gap-8 mt-12">
              {[
                { name: 'Home', href: '/' },
                { name: 'Spices', href: '/products' },
                { name: 'Blends', href: '/products?category=blends' },
                { name: 'Our Story', href: '/#our-story' },
                { name: 'Contact', href: '/#contact' }
              ].map((item) => (
                <Link
                  key={item.name}
                  href={item.href}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="text-4xl font-serif font-bold text-stone-900 hover:text-red-600 transition-colors"
                >
                  {item.name}
                </Link>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
