'use client';

import { motion } from 'motion/react';
import { ShoppingCart, Eye, Star } from 'lucide-react';
import Image from 'next/image';

const products = [
  {
    id: 1,
    name: "Premium Turmeric Powder",
    price: "₹149",
    category: "Pure Spices",
    image: "https://picsum.photos/seed/turmeric/600/800",
    rating: 4.8
  },
  {
    id: 2,
    name: "Authentic Garam Masala",
    price: "₹199",
    category: "Blends",
    image: "https://picsum.photos/seed/masala/600/800",
    rating: 4.9
  },
  {
    id: 3,
    name: "Kashmiri Red Chilli",
    price: "₹179",
    category: "Pure Spices",
    image: "https://picsum.photos/seed/chilli/600/800",
    rating: 4.7
  },
  {
    id: 4,
    name: "Special Chai Masala",
    price: "₹129",
    category: "Blends",
    image: "https://picsum.photos/seed/chai/600/800",
    rating: 5.0
  },
  {
    id: 5,
    name: "Coriander Seeds",
    price: "₹89",
    category: "Whole Spices",
    image: "https://picsum.photos/seed/coriander/600/800",
    rating: 4.6
  },
  {
    id: 6,
    name: "Black Pepper Whole",
    price: "₹249",
    category: "Whole Spices",
    image: "https://picsum.photos/seed/pepper/600/800",
    rating: 4.9
  }
];

export default function ProductGrid() {
  return (
    <section id="spices" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div className="max-w-xl">
            <span className="text-red-700 font-bold tracking-widest uppercase text-sm mb-4 block">
              Our Signature Collection
            </span>
            <h2 className="text-4xl md:text-5xl font-serif text-stone-900 leading-tight">
              Bring the Authentic Flavors of India to Your Kitchen
            </h2>
          </div>
          <div className="flex gap-4">
            {['All', 'Pure Spices', 'Blends', 'Whole Spices'].map((tab) => (
              <button
                key={tab}
                className={`px-6 py-2 rounded-full text-sm font-medium transition-all ${
                  tab === 'All'
                    ? 'bg-stone-900 text-white'
                    : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-10">
          {products.map((product, index) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group"
            >
              <div className="relative aspect-[3/4] overflow-hidden rounded-2xl bg-stone-100 mb-6">
                <Image
                  src={product.image}
                  alt={product.name}
                  fill
                  className="object-cover transition-transform duration-700 group-hover:scale-110"
                  referrerPolicy="no-referrer"
                />
                
                {/* Overlay Actions */}
                <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-3">
                  <button className="p-4 bg-white rounded-full text-stone-900 hover:bg-red-700 hover:text-white transition-all transform translate-y-4 group-hover:translate-y-0 duration-300">
                    <ShoppingCart size={20} />
                  </button>
                  <button className="p-4 bg-white rounded-full text-stone-900 hover:bg-red-700 hover:text-white transition-all transform translate-y-4 group-hover:translate-y-0 duration-300 delay-75">
                    <Eye size={20} />
                  </button>
                </div>

                {/* Badge */}
                <div className="absolute top-4 left-4">
                  <span className="px-3 py-1 bg-white/90 backdrop-blur-md rounded-full text-[10px] font-bold uppercase tracking-wider text-stone-900 shadow-sm">
                    {product.category}
                  </span>
                </div>
              </div>

              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-xl font-serif font-bold text-stone-900 mb-1 group-hover:text-red-700 transition-colors">
                    {product.name}
                  </h3>
                  <div className="flex items-center gap-1 text-yellow-500 mb-2">
                    <Star size={14} fill="currentColor" />
                    <span className="text-xs font-bold text-stone-500">{product.rating}</span>
                  </div>
                </div>
                <span className="text-lg font-bold text-stone-900">{product.price}</span>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-20 text-center">
          <button className="px-10 py-4 border-2 border-stone-900 text-stone-900 font-bold rounded-full hover:bg-stone-900 hover:text-white transition-all">
            View All Products
          </button>
        </div>
      </div>
    </section>
  );
}
