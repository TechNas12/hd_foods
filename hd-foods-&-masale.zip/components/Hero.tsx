'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronRight, ChevronLeft } from 'lucide-react';
import Image from 'next/image';

const slides = [
  {
    id: 1,
    title: "Pure Essence of Tradition",
    subtitle: "Handpicked spices from the heart of India, processed with love and care.",
    image: "https://picsum.photos/seed/spices1/1920/1080",
    accent: "text-red-500"
  },
  {
    id: 2,
    title: "Authentic Masala Blends",
    subtitle: "Secret family recipes passed down through generations for the perfect aroma.",
    image: "https://picsum.photos/seed/spices2/1920/1080",
    accent: "text-yellow-500"
  },
  {
    id: 3,
    title: "Quality You Can Taste",
    subtitle: "Zero additives, zero preservatives. Just 100% pure, natural flavor.",
    image: "https://picsum.photos/seed/spices3/1920/1080",
    accent: "text-emerald-500"
  }
];

export default function Hero() {
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrent((prev) => (prev + 1) % slides.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const nextSlide = () => setCurrent((prev) => (prev + 1) % slides.length);
  const prevSlide = () => setCurrent((prev) => (prev - 1 + slides.length) % slides.length);

  return (
    <section className="relative h-screen w-full overflow-hidden bg-stone-900">
      <AnimatePresence mode="wait">
        <motion.div
          key={current}
          initial={{ opacity: 0, scale: 1.1 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
          className="absolute inset-0"
        >
          <div className="absolute inset-0 bg-black/40 z-10" />
          <Image
            src={slides[current].image}
            alt={slides[current].title}
            fill
            className="object-cover"
            priority
            referrerPolicy="no-referrer"
          />
        </motion.div>
      </AnimatePresence>

      <div className="relative z-20 h-full max-w-7xl mx-auto px-6 flex flex-col justify-center">
        <motion.div
          key={`content-${current}`}
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.8 }}
          className="max-w-2xl"
        >
          <span className="inline-block text-white/80 uppercase tracking-[0.3em] text-sm mb-4 font-medium">
            Premium Spices Since 1995
          </span>
          <h1 className="text-6xl md:text-8xl font-serif text-white leading-tight mb-6">
            {slides[current].title.split(' ').map((word, i) => (
              <span key={i} className={i === slides[current].title.split(' ').length - 1 ? slides[current].accent : ''}>
                {word}{' '}
              </span>
            ))}
          </h1>
          <p className="text-xl text-white/70 mb-10 leading-relaxed max-w-lg">
            {slides[current].subtitle}
          </p>
          <div className="flex gap-4">
            <button className="px-8 py-4 bg-red-700 text-white font-bold rounded-full hover:bg-red-800 transition-all transform hover:scale-105 active:scale-95 shadow-xl">
              Shop Collection
            </button>
            <button className="px-8 py-4 bg-white/10 backdrop-blur-md text-white font-bold rounded-full border border-white/20 hover:bg-white/20 transition-all">
              Our Story
            </button>
          </div>
        </motion.div>
      </div>

      {/* Navigation Controls */}
      <div className="absolute bottom-12 right-12 z-30 flex gap-4">
        <button
          onClick={prevSlide}
          className="p-4 rounded-full border border-white/20 text-white hover:bg-white/10 transition-colors backdrop-blur-md"
        >
          <ChevronLeft size={24} />
        </button>
        <button
          onClick={nextSlide}
          className="p-4 rounded-full border border-white/20 text-white hover:bg-white/10 transition-colors backdrop-blur-md"
        >
          <ChevronRight size={24} />
        </button>
      </div>

      {/* Progress Indicators */}
      <div className="absolute bottom-12 left-12 z-30 flex gap-2">
        {slides.map((_, i) => (
          <div
            key={i}
            className={`h-1 transition-all duration-500 rounded-full ${
              i === current ? 'w-12 bg-red-600' : 'w-6 bg-white/30'
            }`}
          />
        ))}
      </div>
    </section>
  );
}
