'use client';

import { motion } from 'motion/react';
import Image from 'next/image';

const features = [
  {
    id: 1,
    title: "Sourced from Origin",
    description: "We travel to the remotest parts of India to find the finest quality whole spices directly from farmers.",
    image: "https://picsum.photos/seed/origin/800/600"
  },
  {
    id: 2,
    title: "Traditional Grinding",
    description: "Our spices are ground at low temperatures to preserve their natural oils and intense aroma.",
    image: "https://picsum.photos/seed/grinding/800/600"
  },
  {
    id: 3,
    title: "Purity Guaranteed",
    description: "Every batch undergoes rigorous quality checks to ensure zero adulteration and maximum potency.",
    image: "https://picsum.photos/seed/purity/800/600"
  }
];

export default function StorySection() {
  return (
    <section id="our-story" className="py-24 bg-stone-50 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center mb-32">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <span className="text-red-700 font-bold tracking-widest uppercase text-sm mb-4 block">
              Our Legacy
            </span>
            <h2 className="text-5xl md:text-6xl font-serif text-stone-900 leading-tight mb-8">
              A Journey of Taste <br />
              <span className="italic text-stone-400">Since 1995</span>
            </h2>
            <p className="text-lg text-stone-600 leading-relaxed mb-8">
              HD Foods & Masale was born out of a passion for authentic Indian flavors. For over two decades, we have been committed to bringing the purest spices from the farm to your table.
            </p>
            <p className="text-lg text-stone-600 leading-relaxed mb-10">
              Our process is rooted in tradition but powered by modern technology, ensuring that every pinch of our masala adds a burst of life to your cooking.
            </p>
            <div className="grid grid-cols-2 gap-8">
              <div>
                <span className="block text-4xl font-serif font-bold text-red-700 mb-2">25+</span>
                <span className="text-sm uppercase tracking-wider text-stone-500 font-bold">Years of Trust</span>
              </div>
              <div>
                <span className="block text-4xl font-serif font-bold text-red-700 mb-2">100%</span>
                <span className="text-sm uppercase tracking-wider text-stone-500 font-bold">Natural Ingredients</span>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <div className="aspect-square rounded-3xl overflow-hidden shadow-2xl relative">
              <Image
                src="https://picsum.photos/seed/legacy/1000/1000"
                alt="Our Legacy"
                fill
                className="object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            {/* Floating Card */}
            <div className="absolute -bottom-10 -left-10 p-8 bg-white/80 backdrop-blur-xl rounded-2xl shadow-xl border border-white/20 max-w-xs hidden md:block">
              <p className="text-stone-800 font-serif italic text-xl mb-4">
                &quot;Spices are the soul of Indian cooking, and we treat them with the respect they deserve.&quot;
              </p>
              <span className="text-sm font-bold uppercase tracking-widest text-red-700">
                — Founder, HD Foods
              </span>
            </div>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {features.map((feature, index) => (
            <motion.div
              key={feature.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.2 }}
              className="group"
            >
              <div className="h-64 rounded-2xl overflow-hidden mb-6 relative">
                <Image
                  src={feature.image}
                  alt={feature.title}
                  fill
                  className="object-cover transition-transform duration-700 group-hover:scale-110"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              </div>
              <h3 className="text-2xl font-serif font-bold text-stone-900 mb-4">
                {feature.title}
              </h3>
              <p className="text-stone-600 leading-relaxed">
                {feature.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
