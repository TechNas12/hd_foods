'use client';

import { motion } from 'motion/react';
import { Instagram, Facebook, Twitter, Mail, Phone, MapPin } from 'lucide-react';
import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="bg-stone-900 text-white pt-24 pb-12">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-16 mb-20">
          {/* Brand Column */}
          <div className="flex flex-col gap-8">
            <Link href="/" className="flex items-center gap-2">
              <div className="w-12 h-12 bg-red-700 rounded-full flex items-center justify-center text-white font-bold text-2xl border-2 border-yellow-500">
                <span className="font-serif italic">HD</span>
              </div>
              <span className="font-serif text-2xl font-bold tracking-tight">
                HD FOODS
              </span>
            </Link>
            <p className="text-stone-400 leading-relaxed">
              Bringing the authentic taste of Indian tradition to your kitchen with premium quality spices and blends since 1995.
            </p>
            <div className="flex gap-4">
              {[Instagram, Facebook, Twitter].map((Icon, i) => (
                <button
                  key={i}
                  className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center hover:bg-red-700 hover:border-red-700 transition-all"
                >
                  <Icon size={18} />
                </button>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-serif text-xl font-bold mb-8">Quick Links</h4>
            <ul className="flex flex-col gap-4">
              {['Home', 'Shop Spices', 'Masala Blends', 'Our Story', 'Recipes', 'Contact'].map((item) => (
                <li key={item}>
                  <Link href="#" className="text-stone-400 hover:text-white transition-colors">
                    {item}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-serif text-xl font-bold mb-8">Contact Us</h4>
            <ul className="flex flex-col gap-6">
              <li className="flex gap-4 text-stone-400">
                <MapPin className="text-red-700 shrink-0" size={20} />
                <span>123 Spice Market, Old Delhi,<br />New Delhi - 110006, India</span>
              </li>
              <li className="flex gap-4 text-stone-400">
                <Phone className="text-red-700 shrink-0" size={20} />
                <span>+91 98765 43210</span>
              </li>
              <li className="flex gap-4 text-stone-400">
                <Mail className="text-red-700 shrink-0" size={20} />
                <span>hello@hdfoods.com</span>
              </li>
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h4 className="font-serif text-xl font-bold mb-8">Newsletter</h4>
            <p className="text-stone-400 mb-6">
              Subscribe to get special offers and authentic Indian recipes.
            </p>
            <form className="flex flex-col gap-4">
              <input
                type="email"
                placeholder="Your email address"
                className="bg-white/5 border border-white/10 rounded-full px-6 py-3 text-sm focus:outline-none focus:border-red-700 transition-colors"
              />
              <button className="bg-red-700 text-white font-bold py-3 rounded-full hover:bg-red-800 transition-all">
                Subscribe
              </button>
            </form>
          </div>
        </div>

        <div className="pt-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6 text-stone-500 text-sm">
          <p>© 2026 HD Foods & Masale. All rights reserved.</p>
          <div className="flex gap-8">
            <Link href="#" className="hover:text-white transition-colors">Privacy Policy</Link>
            <Link href="#" className="hover:text-white transition-colors">Terms of Service</Link>
            <Link href="#" className="hover:text-white transition-colors">Shipping Policy</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
